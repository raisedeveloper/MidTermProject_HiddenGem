function addAnniversary() {
  
}